// ==========================================
// AROMA BOUTIK — Основное приложение
// ==========================================
// Отвечает за: рендеринг карточек, фильтры,
// поиск, анимации, навигацию
// ==========================================

// --- Инициализация при загрузке ---
document.addEventListener('DOMContentLoaded', () => {
  initHeader();
  initSearch();
  initMobileMenu();

  // Если мы на странице каталога — инициализируем каталог
  if (document.querySelector('.products-grid')) {
    initCatalog();
  }

  // Если мы на главной — инициализируем категории
  if (document.querySelector('.categories')) {
    initHomeCategories();
  }
});

// ==========================================
// HEADER — эффект при скролле
// ==========================================
function initHeader() {
  const header = document.querySelector('.header');
  if (!header) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });
}

// ==========================================
// MOBILE MENU — бургер-меню
// ==========================================
function initMobileMenu() {
  const burger = document.querySelector('.burger');
  const nav = document.querySelector('.header__nav');
  if (!burger || !nav) return;

  burger.addEventListener('click', () => {
    burger.classList.toggle('active');
    nav.classList.toggle('active');
    document.body.style.overflow = nav.classList.contains('active') ? 'hidden' : '';
  });

  // Закрываем меню при клике на ссылку
  nav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      burger.classList.remove('active');
      nav.classList.remove('active');
      document.body.style.overflow = '';
    });
  });
}

// ==========================================
// SEARCH — поиск по каталогу
// ==========================================
function initSearch() {
  const searchBtn = document.querySelector('.header__search-btn');
  const searchOverlay = document.querySelector('.search-overlay');
  const searchClose = document.querySelector('.search-overlay__close');
  const searchInput = document.querySelector('.search-overlay__input');
  const searchResults = document.querySelector('.search-overlay__results');

  if (!searchBtn || !searchOverlay) return;

  // Открыть поиск
  searchBtn.addEventListener('click', () => {
    searchOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    setTimeout(() => searchInput.focus(), 300);
  });

  // Закрыть поиск
  const closeSearch = () => {
    searchOverlay.classList.remove('active');
    document.body.style.overflow = '';
    searchInput.value = '';
    searchResults.innerHTML = '';
  };

  searchClose.addEventListener('click', closeSearch);

  // Закрыть по Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && searchOverlay.classList.contains('active')) {
      closeSearch();
    }
  });

  // Поиск в реальном времени
  let searchTimeout;
  searchInput.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    const query = e.target.value.trim().toLowerCase();

    if (query.length < 1) {
      searchResults.innerHTML = '';
      return;
    }

    searchTimeout = setTimeout(() => {
      performSearch(query, searchResults);
    }, 150);
  });
}

function performSearch(query, container) {
  const results = products.filter(p => 
    p.name.toLowerCase().includes(query) ||
    p.brand.toLowerCase().includes(query) ||
    p.category.toLowerCase().includes(query)
  );

  if (results.length === 0) {
    container.innerHTML = `
      <div class="search-overlay__empty">
        <div style="font-size: 2rem; margin-bottom: 16px;">✦</div>
        К сожалению, ничего не найдено
      </div>
    `;
    return;
  }

  container.innerHTML = results.map(p => `
    <div class="search-overlay__result-item" onclick="goToProduct(${p.id})">
      <img src="${p.image}" alt="${p.name}" loading="lazy">
      <div class="search-overlay__result-info">
        <h4>${p.name}</h4>
        <p>${p.brand} · ${p.category} · ${p.price} сомони</p>
      </div>
    </div>
  `).join('');
}

function goToProduct(id) {
  window.location.href = `product.html?id=${id}`;
}

// ==========================================
// CATALOG — каталог товаров
// ==========================================
function initCatalog() {
  const grid = document.querySelector('.products-grid');
  const categoryFilter = document.getElementById('filter-category');
  const brandFilter = document.getElementById('filter-brand');
  const sortFilter = document.getElementById('filter-sort');

  if (!grid) return;

  // Заполняем фильтр брендов
  populateBrandFilter();

  // Рендерим все товары
  renderProducts(products);

  // Обработчики фильтров
  [categoryFilter, brandFilter, sortFilter].forEach(el => {
    if (el) {
      el.addEventListener('change', applyFilters);
    }
  });
}

function populateBrandFilter() {
  const brandFilter = document.getElementById('filter-brand');
  if (!brandFilter) return;

  const brands = [...new Set(products.map(p => p.brand))].sort();

  brandFilter.innerHTML = `
    <option value="all">Все бренды</option>
    ${brands.map(b => `<option value="${b}">${b}</option>`).join('')}
  `;
}

function applyFilters() {
  const category = document.getElementById('filter-category')?.value || 'all';
  const brand = document.getElementById('filter-brand')?.value || 'all';
  const sort = document.getElementById('filter-sort')?.value || 'default';

  let filtered = [...products];

  // Фильтр по категории
  if (category !== 'all') {
    filtered = filtered.filter(p => p.category === category);
  }

  // Фильтр по бренду
  if (brand !== 'all') {
    filtered = filtered.filter(p => p.brand === brand);
  }

  // Сортировка
  switch (sort) {
    case 'price-asc':
      filtered.sort((a, b) => a.price - b.price);
      break;
    case 'price-desc':
      filtered.sort((a, b) => b.price - a.price);
      break;
    case 'name-asc':
      filtered.sort((a, b) => a.name.localeCompare(b.name, 'ru'));
      break;
    case 'name-desc':
      filtered.sort((a, b) => b.name.localeCompare(a.name, 'ru'));
      break;
  }

  renderProducts(filtered);
}

function renderProducts(items) {
  const grid = document.querySelector('.products-grid');
  if (!grid) return;

  if (items.length === 0) {
    grid.innerHTML = `
      <div class="no-results">
        <div class="no-results__icon">✦</div>
        <p class="no-results__text">К сожалению, ничего не найдено</p>
      </div>
    `;
    return;
  }

  grid.innerHTML = items.map(p => `
    <article class="product-card" onclick="goToProduct(${p.id})" style="opacity:0">
      <div class="product-card__img-wrap">
        <img class="product-card__img" src="${p.image}" alt="${p.name}" loading="lazy">
        <span class="product-card__badge">${p.category}</span>
      </div>
      <div class="product-card__info">
        <div class="product-card__brand">${p.brand}</div>
        <h3 class="product-card__name">${p.name}</h3>
        <p class="product-card__desc">${p.description}</p>
        <div class="product-card__footer">
          <div class="product-card__price">${p.price} <span>сомони</span></div>
          <span class="product-card__btn">Подробнее →</span>
        </div>
      </div>
    </article>
  `).join('');

  // Запускаем анимацию появления
  requestAnimationFrame(() => {
    const cards = grid.querySelectorAll('.product-card');
    cards.forEach((card, i) => {
      setTimeout(() => {
        card.style.transition = 'all 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
      }, i * 80);
    });
  });
}

// ==========================================
// HOME CATEGORIES — категории на главной
// ==========================================
function initHomeCategories() {
  const categories = document.querySelectorAll('.category-card');

  categories.forEach(card => {
    const category = card.dataset.category;
    const count = products.filter(p => p.category === category).length;
    const countEl = card.querySelector('.category-card__count');
    if (countEl) {
      countEl.textContent = `${count} ароматов`;
    }

    card.addEventListener('click', () => {
      window.location.href = `catalog.html?category=${encodeURIComponent(category)}`;
    });
  });
}
