// ==========================================
// AROMA BOUTIK — Страница товара
// ==========================================
// Отвечает за: загрузку данных товара по ID,
// отображение детальной информации, ноты
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
  initHeader();
  initMobileMenu();
  initSearch();
  loadProduct();
});

// ==========================================
// Загрузка и отображение товара
// ==========================================
function loadProduct() {
  // Получаем ID товара из URL
  const urlParams = new URLSearchParams(window.location.search);
  const productId = parseInt(urlParams.get('id'));

  // Ищем товар в базе
  const product = products.find(p => p.id === productId);

  if (!product) {
    showProductNotFound();
    return;
  }

  // Заполняем данные на странице
  renderProduct(product);

  // Обновляем заголовок страницы
  document.title = `${product.name} — ${product.brand} | AROMA BOUTIK`;
}

function renderProduct(product) {
  const container = document.querySelector('.product-detail__inner');
  if (!container) return;

  container.innerHTML = `
    <div class="product-detail__image-wrap">
      <img class="product-detail__image" src="${product.image}" alt="${product.name}" loading="eager">
    </div>

    <div class="product-detail__info">
      <a href="catalog.html" class="product-detail__back">
        ← Вернуться в каталог
      </a>

      <div class="product-detail__brand">${product.brand}</div>
      <h1 class="product-detail__name">${product.name}</h1>
      <div class="product-detail__category">${product.category} · ${product.volume}</div>

      <div class="product-detail__price">${product.price} <span>сомони</span></div>
      <div class="product-detail__divider"></div>

      <p class="product-detail__desc">${product.description}</p>

      <div class="product-detail__volume">Объём: ${product.volume}</div>

      <h2 class="product-detail__notes-title">Пирамидка аромата</h2>

      <div class="notes-grid">
        <div class="note-card">
          <div class="note-card__label">Верхние ноты</div>
          <div class="note-card__items">${product.topNotes.join('<br>')}</div>
        </div>
        <div class="note-card">
          <div class="note-card__label">Средние ноты</div>
          <div class="note-card__items">${product.middleNotes.join('<br>')}</div>
        </div>
        <div class="note-card">
          <div class="note-card__label">Базовые ноты</div>
          <div class="note-card__items">${product.baseNotes.join('<br>')}</div>
        </div>
      </div>
    </div>
  `;

  // Анимация появления
  requestAnimationFrame(() => {
    container.style.opacity = '0';
    container.style.transform = 'translateY(20px)';
    container.style.transition = 'all 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94)';

    setTimeout(() => {
      container.style.opacity = '1';
      container.style.transform = 'translateY(0)';
    }, 100);
  });
}

function showProductNotFound() {
  const container = document.querySelector('.product-detail__inner');
  if (!container) return;

  container.innerHTML = `
    <div style="grid-column: 1 / -1; text-align: center; padding: 100px 20px;">
      <div style="font-size: 3rem; margin-bottom: 20px; opacity: 0.3;">✦</div>
      <h2 style="font-family: var(--font-main); font-size: 1.8rem; margin-bottom: 16px;">Товар не найден</h2>
      <p style="color: var(--color-gray); margin-bottom: 32px;">Возможно, он был удалён или вы перешли по неверной ссылке.</p>
      <a href="catalog.html" class="hero__cta">Перейти в каталог</a>
    </div>
  `;

  document.title = 'Товар не найден | AROMA BOUTIK';
}
