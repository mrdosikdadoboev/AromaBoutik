// ==========================================
// AROMA BOUTIK — База данных парфюмерии
// ==========================================
// Здесь хранятся все товары каталога.
// Чтобы добавить новый парфюм — просто скопируйте
// шаблон объекта и измените данные.
// ==========================================

const products = [
  {
    id: 1,
    name: "Dior Sauvage",
    brand: "Dior",
    price: 850,
    category: "Мужские",
    description: "Свежий, насыщенный и современный аромат с древесными и пряными нотами. Создан для мужчины, который ценит свободу и приключения.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1594035910387-fea47794261f?w=600&h=600&fit=crop",
    topNotes: ["Бергамот", "Перец"],
    middleNotes: ["Лаванда", "Герань"],
    baseNotes: ["Кедр", "Амброксан"]
  },
  {
    id: 2,
    name: "Chanel No. 5",
    brand: "Chanel",
    price: 1200,
    category: "Женские",
    description: "Легендарный цветочно-альдегидный аромат, символ женственности и элегантности. Вневременная классика от Коко Шанель.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1541643600914-78b084683601?w=600&h=600&fit=crop",
    topNotes: ["Альдегиды", "Нероли", "Иланг-иланг"],
    middleNotes: ["Жасмин", "Роза"],
    baseNotes: ["Сандал", "Ваниль", "Ветивер"]
  },
  {
    id: 3,
    name: "Bleu de Chanel",
    brand: "Chanel",
    price: 980,
    category: "Мужские",
    description: "Древесно-ароматический парфюм для мужчины, который ценит свободу и уверенность. Глубокий и многогранный.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=600&h=600&fit=crop",
    topNotes: ["Цитрус", "Мята", "Розовый перец"],
    middleNotes: ["Герань", "Жасмин", "Исо-E-Super"],
    baseNotes: ["Кедр", "Ладан", "Ветивер"]
  },
  {
    id: 4,
    name: "Tom Ford Black Orchid",
    brand: "Tom Ford",
    price: 1450,
    category: "Женские",
    description: "Роскошный восточно-цветочный аромат с нотами чёрной орхидеи. Тёмный, чувственный и незабываемый.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?w=600&h=600&fit=crop",
    topNotes: ["Трюфель", "Иланг-иланг", "Чёрная смородина"],
    middleNotes: ["Чёрная орхидея", "Лотос"],
    baseNotes: ["Пачули", "Ваниль", "Ветивер"]
  },
  {
    id: 5,
    name: "Acqua di Gio",
    brand: "Giorgio Armani",
    price: 780,
    category: "Мужские",
    description: "Свежий морской аромат, вдохновлённый средиземноморским побережьем. Лёгкий, бодрящий и универсальный.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1523293182086-7651a899d37f?w=600&h=600&fit=crop",
    topNotes: ["Лайм", "Лимон", "Бергамот"],
    middleNotes: ["Морские ноты", "Жасмин", "Персик"],
    baseNotes: ["Мускус", "Кедр", "Дубовый мох"]
  },
  {
    id: 6,
    name: "Yves Saint Laurent Libre",
    brand: "Yves Saint Laurent",
    price: 920,
    category: "Женские",
    description: "Смелый аромат свободы, сочетающий французскую лаванду и марокканский апельсиновый цвет. Для сильной женщины.",
    volume: "90 мл",
    image: "https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?w=600&h=600&fit=crop",
    topNotes: ["Лаванда", "Мандарин", "Чёрная смородина"],
    middleNotes: ["Апельсиновый цвет", "Жасмин"],
    baseNotes: ["Ваниль", "Мускус", "Кедр"]
  },
  {
    id: 7,
    name: "Creed Aventus",
    brand: "Creed",
    price: 2100,
    category: "Мужские",
    description: "Премиальный фруктово-древесный аромат для победителей. Сочетание ананаса, дыма и дубового мха.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=600&h=600&fit=crop",
    topNotes: ["Ананас", "Бергамот", "Чёрная смородина"],
    middleNotes: ["Берёза", "Пачули", "Жасмин"],
    baseNotes: ["Мускус", "Дубовый мох", "Ваниль"]
  },
  {
    id: 8,
    name: "Jo Malone Wood Sage & Sea Salt",
    brand: "Jo Malone",
    price: 650,
    category: "Унисекс",
    description: "Аромат морского бриза и дикой природы. Лёгкий, естественный и универсальный — подходит всем.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1590736969955-71cc94901144?w=600&h=600&fit=crop",
    topNotes: ["Морская соль", "Амбретта"],
    middleNotes: ["Шалфей", "Древесные ноты"],
    baseNotes: ["Секвойя", "Мускус"]
  },
  {
    id: 9,
    name: "Gucci Bloom",
    brand: "Gucci",
    price: 890,
    category: "Женские",
    description: "Насыщенный цветочный аромат, словно сад в полном цвету. Белые цветы, жасмин и тубероза в гармонии.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=600&h=600&fit=crop",
    topNotes: ["Рангунский креп", "Жасмин"],
    middleNotes: ["Тубероза", "Ирис"],
    baseNotes: ["Сандал", "Мускус"]
  },
  {
    id: 10,
    name: "Versace Eros",
    brand: "Versace",
    price: 720,
    category: "Мужские",
    description: "Яркий и страстный аромат, вдохновлённый греческой мифологией. Мятная свежесть и ванильная теплота.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1587017539504-67cfbddac569?w=600&h=600&fit=crop",
    topNotes: ["Мята", "Зелёное яблоко", "Лимон"],
    middleNotes: ["Амброксан", "Герань", "Тонка"],
    baseNotes: ["Ваниль", "Ветивер", "Дубовый мох"]
  },
  {
    id: 11,
    name: "Le Labo Santal 33",
    brand: "Le Labo",
    price: 1800,
    category: "Унисекс",
    description: "Культовый древесный аромат с нотами сандала, кожи и кардамона. Минималистичный и узнаваемый.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1594035910387-fea47794261f?w=600&h=600&fit=crop",
    topNotes: ["Кардамон", "Ирис", "Фиалка"],
    middleNotes: ["Сандал", "Кедр", "Амбра"],
    baseNotes: ["Кожа", "Мускус", "Ветивер"]
  },
  {
    id: 12,
    name: "Dolce & Gabbana Light Blue",
    brand: "Dolce & Gabbana",
    price: 680,
    category: "Женские",
    description: "Свежий и игривый средиземноморский аромат. Сицилийский лимон, зелёное яблоко и бамбук.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1541643600914-78b084683601?w=600&h=600&fit=crop",
    topNotes: ["Сицилийский лимон", "Зелёное яблоко", "Колокольчик"],
    middleNotes: ["Бамбук", "Жасмин", "Белая роза"],
    baseNotes: ["Кедр", "Мускус", "Амбра"]
  },
  {
    id: 13,
    name: "Paco Rabanne 1 Million",
    brand: "Paco Rabanne",
    price: 750,
    category: "Мужские",
    description: "Дерзкий и роскошный аромат в золотом флаконе. Пряные ноты мяты, кровавого мандарина и кожи.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?w=600&h=600&fit=crop",
    topNotes: ["Грейпфрут", "Мята", "Кровавый мандарин"],
    middleNotes: ["Роза", "Корица", "Пряные ноты"],
    baseNotes: ["Кожа", "Древесные ноты", "Амбра"]
  },
  {
    id: 14,
    name: "Maison Francis Kurkdjian Baccarat Rouge 540",
    brand: "Maison Francis Kurkdjian",
    price: 2500,
    category: "Унисекс",
    description: "Эксклюзивный роскошный аромат с нотами шафрана, амбры и кедра. Настоящее произведение искусства.",
    volume: "70 мл",
    image: "https://images.unsplash.com/photo-1590736969955-71cc94901144?w=600&h=600&fit=crop",
    topNotes: ["Шафран", "Миндаль"],
    middleNotes: ["Кедр", "Жасмин"],
    baseNotes: ["Амбра", "Древесные ноты", "Мускус"]
  },
  {
    id: 15,
    name: "Lancôme La Vie Est Belle",
    brand: "Lancôme",
    price: 820,
    category: "Женские",
    description: "Сладкий и жизнерадостный аромат счастья. Ирис, пачули и ваниль в гармоничном сочетании.",
    volume: "100 мл",
    image: "https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?w=600&h=600&fit=crop",
    topNotes: ["Чёрная смородина", "Груша"],
    middleNotes: ["Ирис", "Жасмин", "Апельсиновый цвет"],
    baseNotes: ["Пачули", "Ваниль", "Пraline"]
  }
];

// Экспортируем для использования в других файлах
if (typeof module !== 'undefined' && module.exports) {
  module.exports = products;
}
